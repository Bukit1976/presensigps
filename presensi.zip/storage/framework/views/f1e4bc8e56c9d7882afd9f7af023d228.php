<?php
function selisih($jam_masuk, $jam_keluar)
{
    [$h, $m, $s] = explode(':', $jam_masuk);
    $dtAwal = mktime($h, $m, $s, '1', '1', '1');
    [$h, $m, $s] = explode(':', $jam_keluar);
    $dtAkhir = mktime($h, $m, $s, '1', '1', '1');
    $dtSelisih = $dtAkhir - $dtAwal;
    $totalmenit = $dtSelisih / 60;
    $jam = explode('.', $totalmenit / 60);
    $sisamenit = $totalmenit / 60 - $jam[0];
    $sisamenit2 = $sisamenit * 60;
    $jml_jam = $jam[0];
    return $jml_jam . ':' . round($sisamenit2);
}
?>
<?php $__currentLoopData = $presensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $foto_in = Storage::url('uploads/absensi/' . $d->foto_in);
        $foto_out = Storage::url('uploads/absensi/' . $d->foto_out);
    ?>
    <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($d->nik); ?></td>
        <td><?php echo e($d->nama_lengkap); ?></td>
        <td><?php echo e($d->nama_dept); ?></td>
        <td><?php echo e($d->jam_in); ?></td>
        <td>
            <img src="<?php echo e(url($foto_in)); ?>" class="avatar" alt="">
        </td>
        <td><?php echo $d->jam_out != null ? $d->jam_out : '<span class="badge bg-primary">Belum Absen</span>'; ?></td>
        <td>
            <?php if($d->jam_out != null): ?>
                <img src="<?php echo e(url($foto_out)); ?>" class="avatar" alt="">
            <?php else: ?>
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-clock-pause" width="24"
                    height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                    stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <path d="M20.942 13.018a9 9 0 1 0 -7.909 7.922"></path>
                    <path d="M12 7v5l2 2"></path>
                    <path d="M17 17v5"></path>
                    <path d="M21 17v5"></path>
                </svg>
            <?php endif; ?>
        </td>
        <td>
            <?php if($d->jam_in >= '09:00'): ?>
                <?php
                    $jamterlambat = selisih('09:00:00', $d->jam_in);
                ?>
                <span class="badge bg-danger">Terlambat <?php echo e($jamterlambat); ?></span>
            <?php else: ?>
                <span class="badge bg-success">On Time</span>
            <?php endif; ?>
        </td>
        <td>
            <a href="#" class="btn btn-primary tampilkanpeta"id="<?php echo e($d->id); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-map-search" width="24"
                    height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                    stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <path d="M11 18l-2 -1l-6 3v-13l6 -3l6 3l6 -3v8"></path>
                    <path d="M9 4v13"></path>
                    <path d="M15 7v5"></path>
                    <path d="M18 18m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0"></path>
                    <path d="M20.2 20.2l1.8 1.8"></path>
                </svg>
            </a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
    $(function() {
        $(".tampilkanpeta").click(function(e) {
            var id = $(this).attr("id");
            $.ajax({
                type: 'POST',
                url: '/tampilkanpeta',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    id: id
                },
                cache: false,
                success: function(respond) {
                    $("#loadmap").html(respond);
                }
            });
            $("#modal-tampilkanpeta").modal("show");
        });
    });
</script>
<?php /**PATH D:\PRESENSI\absenbukit\resources\views/presensi/getpresensi.blade.php ENDPATH**/ ?>